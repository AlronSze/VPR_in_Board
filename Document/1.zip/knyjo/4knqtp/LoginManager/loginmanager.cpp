#include "loginmanager.h"
#include "ui_loginmanager.h"

#include <QDebug>
#include <QMessageBox>
#include <QCryptographicHash>
#include <stdio.h>
#include <stdlib.h>

LoginManager::LoginManager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginManager)
{
    ui->setupUi(this);

    serialport = new SerialPort(this);
    serialport->init_port();

    recordvoice.init_record();
}

LoginManager::~LoginManager()
{
    delete ui;
}

bool LoginManager::match_info(QString acct_str, QString pwd_str)
{
    int acct_len = acct_str.length();
    int psw_len  = pwd_str.length();

    if (acct_len >= INFOMIN && acct_len <= INFOMAX)
    {
        QString pattern(MATCH);
        QRegExp regexp(pattern);

        if (acct_str.indexOf(regexp) == 0)
        {
            if (psw_len >= INFOMIN && psw_len <= INFOMAX)
            {
                return true;
            }
        }
    }

    return false;
}

QString LoginManager::get_md5(QString origin_str, QString md5_salt)
{
    QString salt_str, md5_final;
    QByteArray bb;

    salt_str = origin_str + md5_salt;
    bb = QCryptographicHash::hash(salt_str.toLatin1(), QCryptographicHash::Md5);
    md5_final.append(bb.toHex());

    return md5_final;
}

void LoginManager::on_checkBox_showPwd_clicked()
{
    if(ui->checkBox_showPwd->isChecked())
    {
        ui->lineEdit_pwd->setEchoMode(QLineEdit::Normal);
    }
    else
    {
        ui->lineEdit_pwd->setEchoMode(QLineEdit::Password);
    }
}

void LoginManager::on_pushButton_login_clicked()
{
//    QString acct_str(ui->lineEdit_acct->text());
//    QString pwd_str(ui->lineEdit_pwd->text());

//    if (match_info(acct_str, pwd_str))
//    {
//        acct_str = acct_str.toLower();
//        pwd_str  = get_md5(pwd_str);

        QMessageBox::information(this, tr("Information"), tr("Login successful!"), QMessageBox::Ok);
//        filemanager.show();
//        this->close();
//    }
//    else
//    {
//        QMessageBox::warning(this, tr("Warning!"), tr("Input error!"), QMessageBox::Ok);
//    }
}

void LoginManager::on_pushButton_reg_clicked()
{
    MFCC Mfcc;
    double *test;
    char tempLow, tempHigh;
    FILE *file;
    int fileLen, inputLen;
    int i;

    if ((file = fopen("/VPR/sound.wav", "rb")) == NULL)
    {
        printf ("open error!");
    }

    fseek(file, 0, SEEK_END);
    fileLen = ftell(file) - 44;
    fseek(file, 44, SEEK_SET);

    inputLen = (fileLen / 2) - ((fileLen / 2) % 256);

    test = (double *)malloc(sizeof(double) * inputLen);

    for (i = 0; i < inputLen; i++)
    {
        fread(&tempLow, sizeof(unsigned char), 1, file);
        fread(&tempHigh, sizeof(unsigned char), 1, file);
        test[i] = (double)(short)(tempLow | (tempHigh << 8));
        if (test[i] == 0.0)
        {
            test[i] = 1.0;
        }
    }

    Mfcc.GetMFCC(test, inputLen);

    free(test);

    QMessageBox::information(this, tr("Information"), tr("Register successful!"), QMessageBox::Ok);

//    QString acct_str(ui->lineEdit_acct->text());
//    QString pwd_str(ui->lineEdit_pwd->text());

//    if (match_info(acct_str, pwd_str))
//    {
//        acct_str = acct_str.toLower();
//        pwd_str  = get_md5(pwd_str);
//        QMessageBox::information(this, tr("Information"), tr("Register successful!"), QMessageBox::Ok);
//    }
//    else
//    {
//        QMessageBox::warning(this, tr("Warning!"), tr("Input error!"), QMessageBox::Ok);
//    }
}

void LoginManager::on_pushButton_exit_clicked()
{
    this->close();
}

void LoginManager::on_pushButton_record_clicked()
{
    QMessageBox::information(this, tr("Information"), tr("You have 5 second to record.\nPress OK to start."), QMessageBox::Ok);
    recordvoice.start_record();
    QMessageBox::information(this, tr("Information"), tr("Your record is over!"), QMessageBox::Ok);
    ui->pushButton_login ->setEnabled(true);
    ui->pushButton_reg   ->setEnabled(true);
    ui->pushButton_replay->setEnabled(true);
}

void LoginManager::start_record(void)
{
    recordvoice.start_record();
    QMessageBox::information(this, tr("Information"), tr("Your record is over!"), QMessageBox::Ok);
    ui->pushButton_login ->setEnabled(true);
    ui->pushButton_reg   ->setEnabled(true);
    ui->pushButton_replay->setEnabled(true);
}

void LoginManager::on_pushButton_replay_clicked()
{
    recordvoice.play_record();
}
