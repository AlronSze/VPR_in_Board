#ifndef LOGINMANAGER_H
#define LOGINMANAGER_H

#include "recordvoice.h"
#include "filemanager.h"
#include "mfcc.h"
#include "serialport.h"

#include <QMainWindow>

#define SALT     "salt"
#define MATCH    "^[a-zA-Z_][a-zA-Z_0-9]*"
#define INFOMIN  6
#define INFOMAX  24

namespace Ui {
class LoginManager;
}

class LoginManager : public QMainWindow
{
    Q_OBJECT

public:
    explicit LoginManager(QWidget *parent = 0);
    ~LoginManager();

    void start_record(void);

private slots:
    void on_pushButton_login_clicked();
    void on_pushButton_reg_clicked();
    void on_pushButton_exit_clicked();
    void on_pushButton_record_clicked();
    void on_pushButton_replay_clicked();

    void on_checkBox_showPwd_clicked();

private:
    Ui::LoginManager *ui;

    RecordVoice recordvoice;
    FileManager filemanager;
    class SerialPort *serialport;

    bool match_info(QString acct_str, QString pwd_str);
    QString get_md5(QString origin_str, QString md5_salt = SALT);
};

#endif // LOGINMANAGER_H
