#include "serialport.h"

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>
#include <QDebug>

SerialPort::SerialPort(QObject *parent, class LoginManager *lm) :
    QObject(parent)
{
    loginmanager = lm;
}

void SerialPort::init_port(void)
{
    m_serial_port = new QSerialPort();
    m_serial_port->setPortName("/dev/ttySAC0");
    m_serial_port->open(QIODevice::ReadWrite);
    connect(m_serial_port, SIGNAL(readyRead()), this, SLOT(read_data()));

    m_serial_port->setBaudRate(115200);
    m_serial_port->setDataBits(QSerialPort::Data8);
    m_serial_port->setParity(QSerialPort::NoParity);
    m_serial_port->setStopBits(QSerialPort::OneStop);
    m_serial_port->setFlowControl(QSerialPort::NoFlowControl);
}

void SerialPort::read_data(void)
{
    QByteArray temp("send");
    m_read_buf = m_serial_port->readAll();
    if (m_read_buf[0] == 's')
    {
//        m_serial_port->write(m_read_buf);
        loginmanager->start_record();
    }
    else
    {
        perror("No Match!");
    }
}
