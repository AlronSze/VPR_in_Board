#ifndef SERIALPORT_H
#define SERIALPORT_H

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QObject>

#include "loginmanager.h"

class SerialPort : public QObject
{
    Q_OBJECT
public:
    explicit SerialPort(QObject *parent = 0, class LoginManager *lm = NULL);

    void init_port(void);
    
signals:
    
public slots:
    void read_data(void);
    
private:
    QSerialPort *m_serial_port;
    QByteArray m_read_buf;
    class LoginManager *loginmanager;
};

#endif // SERIALPORT_H
